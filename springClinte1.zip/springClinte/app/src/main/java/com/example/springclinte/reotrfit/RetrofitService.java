package com.example.springclinte.reotrfit;

import com.google.gson.Gson;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitService {
    private Retrofit retrofit;

    public RetrofitService ()
    {
     initializeRetrofit();
    }

    private void initializeRetrofit() {
       retrofit = new Retrofit.Builder()
               .baseUrl("http://172.23.64.1:8080") //This The basss user for connation withe server and app The "Http "Ip of computer ...
               .addConverterFactory(GsonConverterFactory.create(new Gson()))//Her we conver the in to the Gson format using GsonConverterFactory..
               .build();//Her we are bilding the all processs ....
    }

    public Retrofit getRetrofit() {
        return retrofit;
    }
}
