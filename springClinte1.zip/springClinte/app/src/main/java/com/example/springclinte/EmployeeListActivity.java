package com.example.springclinte;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.example.springclinte.adapter.EmployeeAdapter;
import com.example.springclinte.modell.Employee;
import com.example.springclinte.reotrfit.EmploiyeeApi;
import com.example.springclinte.reotrfit.RetrofitService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class EmployeeListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_list);

        recyclerView = findViewById(R.id.employeeList_recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadEmployees( );
    }

    private void loadEmployees() {
        RetrofitService retrofitService = new RetrofitService();
        EmploiyeeApi employeeApi = retrofitService.getRetrofit().create(EmploiyeeApi.class);
        employeeApi.getAllEmployees()
                .enqueue(new Callback<List<Employee>>() {
                    @Override
                    public void onResponse(Call<List<Employee>> call, Response<List<Employee>> response) {
                        populatrListView(response.body()) ;

                    }

                    private void populatrListView(List<Employee> employeeList) {
                        EmployeeAdapter employeeAdapter = new EmployeeAdapter(employeeList);
                        recyclerView.setAdapter(employeeAdapter);

                    }

                    @Override
                    public void onFailure(Call<List<Employee>> call, Throwable t) {
                        Toast.makeText(EmployeeListActivity.this, "Failled to load emplyee", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}